package br.edu.ifam.saf.modelo;

public enum Perfil {
    CLIENTE, FUNCIONARIO, ADMINISTRADOR
}
